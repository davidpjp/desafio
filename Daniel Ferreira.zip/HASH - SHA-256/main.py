import hashlib
import itertools
from tqdm import tqdm
import time
import sys
import json

def ChoiseLang():
    while True:
        try:
            lang = input(r"""
        .--..--..--..--..--..--..--..--..--..--. 
       / .. \.. \.. \.. \.. \.. \.. \.. \.. \.. \
       \ \/\ `'\ `'\ `'\ `'\ `'\ `'\ `'\ `'\ \/ /
        \/ /`--'`--'`--'`--'`--'`--'`--'`--'\/ /
        / /\                                / /\ 
       / /\ \      Choose a language       / /\ \
       \ \/ /                              \ \/ /
        \/ /       PT - Português           \/ / 
        / /\       ENG - English            / /\ 
       / /\ \      FR - French             / /\ \
       \ \/ /                              \ \/ /
        \/ /                                \/ /               
        / /\.--..--..--..--..--..--..--..--./ /\ 
       / /\ \.. \.. \.. \.. \.. \.. \.. \.. \/\ \
       \ `'\ `'\ `'\ `'\ `'\ `'\ `'\ `'\ `'\ `' /
        `--'`--'`--'`--'`--'`--'`--'`--'`--'`--'
                        
                    ➔ """)
            lang = lang.strip().upper()
            if lang in ['PT', 'ENG', 'FR']:
                return lang
        except ValueError:
            print()
           
lang = ChoiseLang() 







class Launcher:
    def __init__(self, lang):
        self.lang = lang

    def Translations(self, lang, id):
        path = r"C:\Users\danieltferreira\Desktop\Pasta\Desafio Python\HASH - SHA-256\lang"
        lang_file = f"{lang}.json"  # Por exemplo, se quiser abrir o arquivo 'en.json'
        with open(f"{path}/{lang_file}", "r") as file:
            text = json.load(file)
            translate = text.get(id)
            return (translate)
        
    def hash_string(self, s):
            self.s = s
            return hashlib.sha256(s.encode()).hexdigest()
    
    def brute_force(self):
            
        select = {1:False,2:False,3:False,4:False}
        char = {
                  1:'abcdefghijklmnopqrstuvwxyz',
                  2:'ABCDFGHIJKLMNOPQRSTUVWXYZ',
                  3:'0123456789',
                  4:'!@#$%^&*()_+{}|:<>?"'
            }
        alphabet = ""
        option = ""
        while True:
                try:
                    option = int(input(f"""
                {self.Translations(self.lang, "add_char")}
                0 - {self.Translations(self.lang, "forward")}
                1 - {char[1]}
                2 - {char[2]}
                3 - {char[3]}
                4 - {char[4]}
                              
                {self.Translations(self.lang, "your_choice")} ⮕ """))

                    if option == 0:
                        if len(alphabet) == 0:
                            print(f"""

{self.Translations(self.lang, "no_types_specified")}

{self.Translations(self.lang, "all_types_for_brute_force")}

""")
                            for value in char.values():
                                alphabet += value[1:]
                            break
                        else:
                            break
                    elif 1 <= option <= 4:
                        alphabet += char[option]
                        select[option] = True
                        continue
                    else:
                        raise ValueError
                except ValueError:
                    continue

        max_length = int(input(f"""
{self.Translations(self.lang, "force_letter")}
{self.Translations(self.lang, "enter_zero_to_force")}
                               
{self.Translations(self.lang, "your_choice")} ⮕ """))
                    
        while True:
            try:
                hash_value = input(f"""
{self.Translations(self.lang, "paste_target_hash")}
Hash:  """)
                  
                if len(hash_value) != 64 or not all(c in '0123456789abcdefABCDEF' for c in hash_value):
                    raise ValueError()   
                else:
                    break       
            except ValueError:
                continue
                  
        found = False
        print(f"""
{self.Translations(self.lang, "initiating_brute_force")}
{self.Translations(self.lang, "hash")}, {hash_value}

""")
        
        start_time = time.time()  

        with tqdm(total=(len(alphabet) ** max_length)) as pbar:
            for length in itertools.count():
                candidates = itertools.product(alphabet, repeat=length)
                for candidate in candidates:
                    if found:
                        break
                    candidate_str = ''.join(candidate)
                    candidate_hash = self.hash_string(candidate_str)
                    pbar.update(1)
                    if candidate_hash == hash_value:
                        found = True
                        break
                if found:
                    break

        elapsed_time = time.time() - start_time  

        if found:
            print(f"""
███████╗ ██████╗ ██╗   ██╗███╗   ██╗██████╗ 
██╔════╝██╔═══██╗██║   ██║████╗  ██║██╔══██╗
█████╗  ██║   ██║██║   ██║██╔██╗ ██║██║  ██║
██╔══╝  ██║   ██║██║   ██║██║╚██╗██║██║  ██║
██║     ╚██████╔╝╚██████╔╝██║ ╚████║██████╔╝
╚═╝      ╚═════╝  ╚═════╝ ╚═╝  ╚═══╝╚═════╝ 

{self.Translations(self.lang, "text")}: {candidate_str}
{self.Translations(self.lang, "hash")}: {candidate_hash}
{self.Translations(self.lang, "time_elapsed")}:, {elapsed_time:.2f} segundos

""")
            time.sleep(2)
            self.FristMenu()
                    
        if not found:
            print("""
                                ███╗   ██╗ ██████╗ ████████╗    ███████╗ ██████╗ ██╗   ██╗███╗   ██╗██████╗ 
                                ████╗  ██║██╔═══██╗╚══██╔══╝    ██╔════╝██╔═══██╗██║   ██║████╗  ██║██╔══██╗
                                ██╔██╗ ██║██║   ██║   ██║       █████╗  ██║   ██║██║   ██║██╔██╗ ██║██║  ██║
                                ██║╚██╗██║██║   ██║   ██║       ██╔══╝  ██║   ██║██║   ██║██║╚██╗██║██║  ██║
                                ██║ ╚████║╚██████╔╝   ██║       ██║     ╚██████╔╝╚██████╔╝██║ ╚████║██████╔╝
                                ╚═╝  ╚═══╝ ╚═════╝    ╚═╝       ╚═╝      ╚═════╝  ╚═════╝ ╚═╝  ╚═══╝╚═════╝ 
    """)
            time.sleep(2)
            self.FristMenu()

    def encrypt(self):
                text = input(f"""
{self.Translations(self.lang, "enter_text_to_encrypt")}
⮕  """)        
                print(f"""
{self.Translations(self.lang, "encrypted_text")}
{self.hash_string(text)}

""")
                time.sleep(3)
                self.FristMenu()

    def wordlist(self):
                found = False
                while True:
                    try:
                            hash_value = input(f"""
{self.Translations(self.lang, "paste_target_hash")}
{self.Translations(self.lang, "hash")}: """)
                    
                            if len(hash_value) != 64 or not all(c in '0123456789abcdefABCDEF' for c in hash_value):
                                raise ValueError()
                            break
                    except ValueError as e:
                            pass
                print(f"""
{self.Translations(self.lang, "initiating_wordlist_attack")}
{self.Translations(self.lang, "hash")}:", {hash_value}
                    """)
                start_time = time.time()  
                wordlist_path = r"C:\Users\danieltferreira\Desktop\Pasta\Desafio Python\Back\rockyou.txt"
                with open(wordlist_path, "r", encoding="utf-8") as worldlist_file:
                    num_lines = sum(1 for _ in wordlist_path)  # Conta o número total de linhas na wordlist
                    with tqdm(total=num_lines) as pbar:
                            for line in worldlist_file:
                                if found:
                                        break
                                candidate_str = line.strip()
                                candidate_hash = hashlib.sha256(candidate_str.encode()).hexdigest()
                                pbar.update(1)  # Atualiza a barra de progresso
                                if candidate_hash == hash_value:
                                        found = True
                                        break

                            elapsed_time = time.time() - start_time  

                if found:
                    print(f"""
███████╗ ██████╗ ██╗   ██╗███╗   ██╗██████╗ 
██╔════╝██╔═══██╗██║   ██║████╗  ██║██╔══██╗
█████╗  ██║   ██║██║   ██║██╔██╗ ██║██║  ██║
██╔══╝  ██║   ██║██║   ██║██║╚██╗██║██║  ██║
██║     ╚██████╔╝╚██████╔╝██║ ╚████║██████╔╝
╚═╝      ╚═════╝  ╚═════╝ ╚═╝  ╚═══╝╚═════╝ 

{self.Translations(self.lang, "text")}: {candidate_str}
{self.Translations(self.lang, "hash")}: {candidate_hash}
{self.Translations(self.lang, "time_elapsed")}:", {elapsed_time:.2f} segundos
                            """)
                    time.sleep(2)
                    self.FristMenu()
                    
                if not found:
                    print("""
███╗   ██╗ ██████╗ ████████╗    ███████╗ ██████╗ ██╗   ██╗███╗   ██╗██████╗ 
████╗  ██║██╔═══██╗╚══██╔══╝    ██╔════╝██╔═══██╗██║   ██║████╗  ██║██╔══██╗
██╔██╗ ██║██║   ██║   ██║       █████╗  ██║   ██║██║   ██║██╔██╗ ██║██║  ██║
██║╚██╗██║██║   ██║   ██║       ██╔══╝  ██║   ██║██║   ██║██║╚██╗██║██║  ██║
██║ ╚████║╚██████╔╝   ██║       ██║     ╚██████╔╝╚██████╔╝██║ ╚████║██████╔╝
╚═╝  ╚═══╝ ╚═════╝    ╚═╝       ╚═╝      ╚═════╝  ╚═════╝ ╚═╝  ╚═══╝╚═════╝ 
    """)
                    time.sleep(2)
                    self.FristMenu()

    def FristMenu(self):
        while True:
            try:
                option = int(input(f'''
 .--..--..--..--..--..--..--..--..--..--..--..--..--..--..--. 
/ .. \.. \.. \.. \.. \.. \.. \.. \.. \.. \.. \.. \.. \.. \.. \\
\ \/\ `'\ `'\ `'\ `'\ `'\ `'\ `'\ `'\ `'\ `'\ `'\ `'\ `'\ \/ /
 \/ /`--'`--'`--'`--'`--'`--'`--'`--'`--'`--'`--'`--'`--'\/ / 
 / /\   ██████   ██████                                  / /\ 
/ /\ \ ░░██████ ██████                                  / /\ \\
\ \/ /  ░███░█████░███   ██████  ████████   █████ ████  \ \/ /
 \/ /   ░███░░███ ░███  ███░░███░░███░░███ ░░███ ░███    \/ / 
 / /\   ░███ ░░░  ░███ ░███████  ░███ ░███  ░███ ░███    / /\ 
/ /\ \  ░███      ░███ ░███░░░   ░███ ░███  ░███ ░███   / /\ \\
\ \/ /  █████     █████░░██████  ████ █████ ░░████████  \ \/ /
 \/ /  ░░░░░     ░░░░░  ░░░░░░  ░░░░ ░░░░░   ░░░░░░░░    \/ / 
 / /\.--..--..--..--..--..--..--..--..--..--..--..--..--./ /\ 
/ /\ \.. \.. \.. \.. \.. \.. \.. \.. \.. \.. \.. \.. \.. \/\ \\
\ `'\ `'\ `'\ `'\ `'\ `'\ `'\ `'\ `'\ `'\ `'\ `'\ `'\ `'\ `' /
 `--'`--'`--'`--'`--'`--'`--'`--'`--'`--'`--'`--'`--'`--'`--' 
                                   
                    1 ⮕ {self.Translations(self.lang, "brute_force")}
                    2 ⮕ {self.Translations(self.lang, "encrypt")}
                    3 ⮕ {self.Translations(self.lang, "wordlist_attack")} 

                    0 ⮕ {self.Translations(self.lang, "leave")} 

                    {self.Translations(self.lang, "your_choice")}  ➔  '''))
                if option < 0 or option > 3:
                    raise ValueError()
                elif option == 1:
                    self.brute_force()
                elif option == 2:
                    self.encrypt()
                elif option == 3:
                    self.wordlist()
                elif option == 0:
                    sys.exit()
            except ValueError:
                continue 

launcher = Launcher(lang)  
launcher.FristMenu()


















