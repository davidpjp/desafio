import hashlib
import itertools
import string

# Dicionário para armazenar as mensagens em diferentes idiomas
messages = {
    'en': {
        'enter_hash': "Enter the SHA256 hash to decrypt: ",
        'hash_is': "The Hash is: ",
        'hash_not_found': "Hash not found. Increase the number of characters.",
        'enter_string': "Enter the string to encrypt: ",
        'hash_of_string': "The SHA256 hash of the string is: ",
        'invalid_option': "Invalid option. Please try again.",
        'decrypt_hash': "Decrypt Hash with Brute Force (Slower)",
        'decrypt_hash_with_wordlist': "Decrypt Hash with Wordlist (Faster)",
        'encrypt_string': "Encrypt String",
        'exit': "Exit",
        'choose_option': "Choose an option: ",
        'language_menu': "LANGUAGE MENU",
        'english': "English",
        'portuguese': "Portuguese"
    },
    'pt': {
        'enter_hash': "Insira a hash SHA256 para desencriptar: ",
        'hash_is': "A Hash é: ",
        'hash_not_found': "Hash não encontrada. Aumente o número de caractéres.",
        'enter_string': "Insira a string para encriptar: ",
        'hash_of_string': "A hash SHA256 da string é: ",
        'invalid_option': "Opção inválida. Por favor, tente novamente.",
        'decrypt_hash': "Desencriptar Hash com Força Bruta (Lento)",
        'decrypt_hash_with_wordlist': "Desencriptar Hash com Wordlist (Rápido)",
        'encrypt_string': "Encriptar String",
        'exit': "Sair",
        'choose_option': "Escolha uma opção: ",
        'language_menu': "MENU DE IDIOMA",
        'english': "Inglês",
        'portuguese': "Português"
    }
}

# Função para selecionar o idioma
def select_language():
    while True:
        print("\n\033[1;33m" + "="*30)
        print("\t" + messages['en']['language_menu'])
        print("" + "="*30)
        print("\n1. " + messages['en']['english'])
        print("2. " + messages['en']['portuguese'])
        print("\n" + "="*30 + "\033[0m")
        choice = input("\n\033[1;32m" + messages['en']['choose_option'] + "\033[0m")
        if choice == '1':
            return 'en'
        elif choice == '2':
            return 'pt'
        else:
            print("\n\033[1;31m" + messages['en']['invalid_option'] + "\033[0m")

# Selecionar o idioma antes de executar o programa
lang = select_language()

def sha256_hash(string):
    return hashlib.sha256(string.encode()).hexdigest()

def brute_force(charset, maxlength):
    return (''.join(candidate)
        for candidate in itertools.chain.from_iterable(itertools.product(charset, repeat=i)
        for i in range(1, maxlength + 1)))

def decrypt_hash():
    hash_to_crack = input("\033[1;32m" + messages[lang]['enter_hash'] + "\033[0m")
    charset = string.ascii_lowercase + string.ascii_uppercase + string.digits + string.whitespace + string.punctuation
    found = False
    for attempt in brute_force(charset, 5):  # Número de caractéres
        if sha256_hash(attempt) == hash_to_crack:
            print(f"\n\033[1;32m" + messages[lang]['hash_is'] + f"{attempt}\033[0m")
            found = True
            break
    if not found:
        print("\033[1;31m" + messages[lang]['hash_not_found'] + "\033[0m")

def decrypt_hash_with_wordlist():
    hash_to_crack = input("\033[1;32m" + messages[lang]['enter_hash'] + "\033[0m")
    wordlist_path = "rockyou.txt"  # Caminho fixo para a wordlist
    found = False
    with open(wordlist_path, 'r', encoding='latin-1') as wordlist:  # Abre a wordlist
        for word in wordlist:  # Itera sobre cada palavra na wordlist
            word = word.strip()  # Remove espaços em branco e quebras de linha
            if sha256_hash(word) == hash_to_crack:  # Compara o hash da palavra com o hash a ser quebrado
                print(f"\n\033[1;32m" + messages[lang]['hash_is'] + f"{word}\033[0m")
                found = True
                break
    if not found:
        print("\n\033[1;31m" + messages[lang]['hash_not_found'] + "\033[0m")

def encrypt_string():
    string_to_encrypt = input("\033[1;32m" + messages[lang]['enter_string'] + "\033[0m")
    print(f"\n\033[1;32m" + messages[lang]['hash_of_string'] + f"{sha256_hash(string_to_encrypt)}\033[0m")

def main():
    print_title = True
    while True:
        if print_title:
            print("\n\033[1;33m" + "="*50)
            print("""
 _____                                              _____ 
( ___ )                                            ( ___ )
 |   |~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|   | 
 |   |                                              |   | 
 |   |     ____  _   _    _    ____  ____   __      |   | 
 |   |    / ___|| | | |  / \  |___ \| ___| / /_     |   | 
 |   |    \___ \| |_| | / _ \   __) |___ \| '_ \    |   | 
 |   |     ___) |  _  |/ ___ \ / __/ ___) | (_) |   |   | 
 |   |    |____/|_| |_/_/   \_\_____|____/ \___/    |   | 
 |   |                                              |   | 
 |   |                                              |   | 
 |___|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|___| 
(_____)                                            (_____)                  
\033[0m""")
        print_title = False
        print("\033[1;33m" + "="*50)
        print("\n1. " + messages[lang]['decrypt_hash'])
        print("2. " + messages[lang]['decrypt_hash_with_wordlist'])
        print("3. " + messages[lang]['encrypt_string']) 
        print("4. " + messages[lang]['exit'])
        print("\n" + "="*50 + "\033[0m")
        choice = input("\033[1;32m" + messages[lang]['choose_option'] + "\033[0m")
        if choice == '1':
            decrypt_hash()
        elif choice == '2':
            decrypt_hash_with_wordlist()
        elif choice == '3':
            encrypt_string()
        elif choice == '4':
            break
        else:
            print("\n\033[1;31m" + messages[lang]['invalid_option'] + "\033[0m")

if __name__ == "__main__":
    main()